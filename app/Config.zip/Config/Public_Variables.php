<?php

class Public_Variables
{
    public $BASE_URL = '/web/chip/';
    public $ASSETS_URL = '/web/chip/assets_main/';
    public $db_pass = '';
    public $WS_SERV = "wss://free.blr2.piesocket.com/v3/1?api_key=P5u7Bm0oLAfw4QQMPGH45yzAt3L0Bs4LXmgXi74n&notify_self=0";
}
